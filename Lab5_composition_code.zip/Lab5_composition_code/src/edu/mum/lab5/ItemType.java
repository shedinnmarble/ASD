package edu.mum.lab5;

/**
 * Created by Dewei Xiang on 7/23/2017.
 */
public enum ItemType {
    BOOK,
    DVD
}
