/**
 * Created by Dewei Xiang on 8/6/2017.
 */
public class MostFavoredCustomer {
    private String name;

    public MostFavoredCustomer(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
