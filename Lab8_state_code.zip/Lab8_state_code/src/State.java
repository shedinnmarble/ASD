/**
 * Created by Dewei Xiang on 8/6/2017.
 */
interface State {
    void pull(CeilingFanPullChain wrapper, String button);
}
