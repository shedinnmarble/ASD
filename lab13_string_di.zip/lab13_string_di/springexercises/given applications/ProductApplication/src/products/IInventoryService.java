package products;

/**
 * Created by Dewei Xiang on 9/17/2017.
 */
public interface IInventoryService {
    public int getNumberInStock(int productNumber);
}
