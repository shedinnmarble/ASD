/**
 * Created by Dewei Xiang on 8/6/2017.
 */
public interface IOrderHandler {
    boolean handleOrder(Order order);

}
